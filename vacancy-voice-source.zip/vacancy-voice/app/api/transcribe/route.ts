import { fail,groq,protect,ServiceError } from '@/lib/groq';
export async function POST(request:Request){try{
  protect(request);
  if(Number(request.headers.get('content-length'))>11*1024*1024) throw new ServiceError(413,'Запись слишком большая. Запиши ответ короче двух минут.');
  const data=await request.formData();const audio=data.get('audio');
  if(!(audio instanceof File)||audio.size<100)throw new ServiceError(400,'Запись пустая. Попробуй записать ответ ещё раз.');
  if(audio.size>10*1024*1024)throw new ServiceError(413,'Запись слишком большая. Запиши ответ короче двух минут.');
  if(!['audio/webm','audio/mp4','audio/ogg','audio/wav','audio/mpeg','video/webm'].includes(audio.type.split(';')[0]))throw new ServiceError(400,'Этот формат записи не поддерживается. Попробуй другой браузер или введи текст.');
  const form=new FormData();form.append('file',audio,audio.type.includes('mp4')?'answer.m4a':audio.type.includes('ogg')?'answer.ogg':'answer.webm');form.append('model','whisper-large-v3-turbo');form.append('language','ru');form.append('response_format','verbose_json');form.append('temperature','0');
  const result=await groq('audio/transcriptions',form) as {text?:string;segments?:{no_speech_prob?:number}[]};
  const text=result.text?.trim();
  if(!text || /^продолжение\s+следует[.!…\s]*$/iu.test(text) || (result.segments?.length && result.segments.every(s=>(s.no_speech_prob??0)>0.85)))throw new ServiceError(422,'Не удалось расслышать ответ. Попробуйте записать его ещё раз или напишите текстом.');
  if(text.length>5000)throw new ServiceError(422,'Ответ получился слишком длинным. Запиши его короче.');
  return Response.json({text},{headers:{'Cache-Control':'no-store'}});
}catch(e){return fail(e)}}
