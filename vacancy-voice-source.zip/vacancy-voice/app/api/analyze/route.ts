import { AnalysisInput, AnalysisSchema } from '@/lib/vacancy';
import { analyzePrompt,fail,inputJson,model,protect } from '@/lib/groq';
export async function POST(request:Request){try{protect(request);const data=AnalysisInput.parse(await inputJson(request));return Response.json(await model(analyzePrompt(data.questionIndex),{currentAnswer:data.answers[data.questionIndex],context:data.answers},AnalysisSchema),{headers:{'Cache-Control':'no-store'}})}catch(e){return fail(e)}}
