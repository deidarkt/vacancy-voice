import { GenerateInput,VacancySchema } from '@/lib/vacancy';
import { GENERATE_PROMPT,fail,inputJson,model,protect } from '@/lib/groq';
export async function POST(request:Request){try{protect(request);const data=GenerateInput.parse(await inputJson(request));return Response.json(await model(GENERATE_PROMPT,data,VacancySchema),{headers:{'Cache-Control':'no-store'}})}catch(e){return fail(e)}}
