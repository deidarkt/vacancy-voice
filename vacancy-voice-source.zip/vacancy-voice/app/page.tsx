'use client';

import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { z } from 'zod';
import { ArrowRight, ArrowLeft, Check, Mic, Square, RotateCcw, Copy, Download, LoaderCircle, X, FileText, ChevronRight, Menu } from 'lucide-react';
import { Analysis, AnalysisSchema, AnswersSchema, VacancySchema, questions, vacancyText } from '@/lib/vacancy';

type Phase = 'idle'|'permission'|'recording'|'transcribing'|'analyzing'|'generating';
type View = 'intro'|'questions'|'finish'|'result';
const STORAGE='vacancy-voice-v1';
const empty = () => ['', '', '', ''];
const unchecked = () => [false,false,false,false];
const actions = [
 ['card-vacancy','Создать вакансию','Расскажите о работе — Искра соберёт описание из ваших ответов.'],
 ['card-candidates','Разобрать отклики','Соберите подходящих кандидатов в короткий список.'],
 ['card-interview','Подготовить интервью','Подберите вопросы под задачи и навыки будущего сотрудника.'],
 ['card-letter','Написать кандидату','Подготовьте приглашение на встречу или обратную связь.'],
 ['card-plan','Спланировать подбор','Разложите поиск сотрудника на понятные шаги.'],
 ['card-report','Посмотреть аналитику','Узнайте, на каком этапе подбора нужна ваша помощь.'],
];
function Asset({name,...props}:{name:string;className?:string}) {return <img src={'/design/'+name+'.svg'} alt="" aria-hidden="true" {...props}/>}
function SoundMeter({source}:{source:MediaStream|null}) {
 const bars=useRef<HTMLDivElement>(null);
 useEffect(()=>{if(!source)return;let ctx:AudioContext|undefined;let frame=0;
  try{ctx=new AudioContext();const node=ctx.createMediaStreamSource(source);const analyser=ctx.createAnalyser();analyser.fftSize=256;analyser.smoothingTimeConstant=.65;node.connect(analyser);const data=new Uint8Array(analyser.frequencyBinCount);
   const draw=()=>{analyser.getByteFrequencyData(data);for(let i=0;i<5;i++){let total=0;for(let k=1+i*4;k<5+i*4;k++)total+=data[k];(bars.current?.children[i] as HTMLElement|undefined)?.style.setProperty('--level',String(Math.max(.12,Math.min(1,total/720))))}frame=requestAnimationFrame(draw)};
   void ctx.resume().catch(()=>{});frame=requestAnimationFrame(draw);return()=>{cancelAnimationFrame(frame);node.disconnect();void ctx?.close().catch(()=>{})};
  }catch{return()=>{cancelAnimationFrame(frame);void ctx?.close().catch(()=>{})}}
 },[source]);
 return <div className="sound-meter" ref={bars} aria-hidden="true"><i/><i/><i/><i/><i/></div>;
}
function Ring({confirmed,index,warning,phase,onClick,stage,finished}:{confirmed:boolean[];index:number;warning:boolean;phase:Phase;onClick:()=>void;stage:string;finished:boolean}) {
 const recording=phase==='recording';const processing=['permission','transcribing','analyzing','generating'].includes(phase);
 return <div className={'ring-stage '+stage}>
  <div className={'ring-wrap '+(phase==='generating'?'generating':'')}>
   <svg className="progress-ring" viewBox="0 0 260 260" aria-hidden="true">{Array.from({length:64},(_,i)=>{const segment=Math.floor(i/16);const filled=confirmed[segment];return <g key={i} transform={`rotate(${i*360/64} 130 130)`}><line x1="130" y1={filled?14:19} x2="130" y2="28" className={'ring-tick '+(filled?'filled ':warning&&segment===index?'warning ':'')} style={{animationDelay:`${i*22}ms`}} strokeLinecap="round"/></g>})}</svg>
   <button className={'ring-center '+(recording?'recording':'')} disabled={processing||stage!=='waiting'||finished} onClick={onClick} aria-label={recording?'Остановить запись':confirmed[index]?'Дополнить ответ голосом':'Начать диктовку'}>
    <span className={'mic-disc '+(recording?'stop':processing?'processing':'')}>{recording?<Square size={18} fill="currentColor"/>:processing?<LoaderCircle className="spin" size={25}/>:finished?<RotateCcw size={25}/>:<Mic size={25} strokeWidth={1.7}/>}</span>
   </button>
  </div>
  <div className="firework" aria-hidden="true">{Array.from({length:36},(_,i)=><i key={i} style={{'--angle':`${i*10}deg`,'--distance':`${95+(i%4)*23}px`,'--delay':`${(i%3)*35}ms`,'--color':i%3===0?'#efb436':'#13c69a'} as CSSProperties}/>)}<Asset name="sparkles"/></div>
 </div>
}
export default function Home(){
 const [view,setView]=useState<View>('intro');const [index,setIndex]=useState(0);
 const [answers,setAnswers]=useState<string[]>(empty);const [confirmed,setConfirmed]=useState<boolean[]>(unchecked);
 const [analyses,setAnalyses]=useState<(Analysis|null)[]>([null,null,null,null]);const [attempts,setAttempts]=useState([0,0,0,0]);
 const [phase,setPhase]=useState<Phase>('idle');const [error,setError]=useState('');const [notice,setNotice]=useState('');
 const [seconds,setSeconds]=useState(0);const [result,setResult]=useState('');const [hydrated,setHydrated]=useState(false);
 const [editorOpen,setEditorOpen]=useState(false);const [draft,setDraft]=useState('');const [stage,setStage]=useState('waiting');
 const [resetOpen,setResetOpen]=useState(false);const [helpOpen,setHelpOpen]=useState(false);const [menuOpen,setMenuOpen]=useState(false);
 const recorder=useRef<MediaRecorder|null>(null);const stream=useRef<MediaStream|null>(null);const chunks=useRef<Blob[]>([]);const retryAudio=useRef<Blob|null>(null);
 const canceled=useRef(false);const requestController=useRef<AbortController|null>(null);const operation=useRef(0);const busyRef=useRef(false);
 const heading=useRef<HTMLHeadingElement>(null);const modalRef=useRef<HTMLDivElement>(null);const timers=useRef<ReturnType<typeof setTimeout>[]>([]);
 const count=confirmed.filter(Boolean).length;const busy=phase!=='idle';const analysis=analyses[index];const warning=!!analysis&&!analysis.ready&&phase==='idle';
 useEffect(()=>{try{const raw=sessionStorage.getItem(STORAGE);if(raw){const s=JSON.parse(raw);const a=AnswersSchema.safeParse(s.answers);if(a.success){setAnswers(a.data);setConfirmed(Array.isArray(s.confirmed)&&s.confirmed.length===4?s.confirmed.map((v:unknown,i:number)=>v===true&&a.data[i].length>0):unchecked());setResult(typeof s.result==='string'?s.result.slice(0,16000).split('\n\nУТОЧНИТЬ ПЕРЕД ПУБЛИКАЦИЕЙ')[0]:'');}}}catch{}setHydrated(true);return()=>{canceled.current=true;operation.current++;requestController.current?.abort();timers.current.forEach(clearTimeout);if(recorder.current?.state==='recording')recorder.current.stop();stream.current?.getTracks().forEach(t=>t.stop())}},[]);
 useEffect(()=>{if(hydrated)try{sessionStorage.setItem(STORAGE,JSON.stringify({answers,confirmed,result}))}catch{setNotice('Браузер не сохраняет черновик. Не закрывайте вкладку до завершения.')}},[answers,confirmed,result,hydrated]);
 useEffect(()=>{heading.current?.focus({preventScroll:true})},[view,index]);
 useEffect(()=>{if(phase!=='recording')return;const start=Date.now();const t=setInterval(()=>{const n=Math.floor((Date.now()-start)/1000);setSeconds(n);if(n>=120){setNotice('Две минуты записи завершены. Обрабатываю ответ.');stopRecording()}},300);return()=>clearInterval(t)},[phase]);
 function idle(){busyRef.current=false;setPhase('idle')}
 function changeQuestion(i:number){if(busyRef.current)return;retryAudio.current=null;setEditorOpen(false);setIndex(i);setView('questions');setError('');setNotice('');setMenuOpen(false)}
 function openEditor(){setDraft(answers[index]);setEditorOpen(true)}
 async function call(path:string,body:BodyInit,json=false){const controller=new AbortController();requestController.current=controller;const timer=setTimeout(()=>controller.abort(),55000);try{const response=await fetch('/api/'+path,{method:'POST',body,headers:json?{'Content-Type':'application/json'}:{},signal:controller.signal});const data=await response.json();if(!response.ok){const parsed=z.object({error:z.string()}).safeParse(data);throw new Error(parsed.success?parsed.data.error:'Не удалось завершить действие. Попробуйте ещё раз.')}return data}finally{clearTimeout(timer);if(requestController.current===controller)requestController.current=null}}
 function showError(e:unknown){setError(e instanceof Error&&e.name!=='AbortError'?e.message:'Ответ не получен вовремя. Попробуйте ещё раз — ваш текст сохранён.')}
 // One operation owns the full voice → transcription → analysis → generation chain.
 async function checkAnswer(snapshot:string[],target:number,accepted:boolean[],id:number){
  setPhase('analyzing');setResult('');setConfirmed(accepted.map((v,i)=>i===target?false:v));
  const data=AnalysisSchema.parse(await call('analyze',JSON.stringify({questionIndex:target,answers:snapshot,attempt:Math.min(attempts[target],2)}),true));
  if(id!==operation.current)return;
  setAnalyses(a=>a.map((v,i)=>i===target?data:v));
  if(!data.ready){setAttempts(a=>a.map((v,i)=>i===target?Math.min(v+1,2):v));return}
  const updated=accepted.map((v,i)=>i===target?true:v);setConfirmed(updated);setAttempts(a=>a.map((v,i)=>i===target?0:v));setEditorOpen(false);
  if(target===1&&accepted[1]&&confirmed[2])setNotice('Первые полгода обновлены. При необходимости уточните дальнейшие планы во вкладке «Планы».');
  if(updated.every(Boolean)){await generateResult(snapshot,id);return}
  setIndex(updated.findIndex(v=>!v));
 }
 async function submitText(){if(busyRef.current||!draft.trim())return;busyRef.current=true;setError('');setNotice('');retryAudio.current=null;setEditorOpen(false);const snapshot=answers.map((v,i)=>i===index?draft.trim():v);setAnswers(snapshot);const id=++operation.current;try{await checkAnswer(snapshot,index,confirmed,id)}catch(e){if(id===operation.current)showError(e)}finally{if(id===operation.current)idle()}}
 async function retryAnalysis(){if(busyRef.current||!answers[index].trim())return;busyRef.current=true;setError('');const id=++operation.current;try{await checkAnswer(answers,index,confirmed,id)}catch(e){if(id===operation.current)showError(e)}finally{if(id===operation.current)idle()}}
 async function transcribe(blob:Blob,target:number){busyRef.current=true;setPhase('transcribing');retryAudio.current=blob;const id=++operation.current;try{const form=new FormData();form.append('audio',blob,blob.type.includes('mp4')?'answer.m4a':'answer.webm');const data=z.object({text:z.string().min(1)}).parse(await call('transcribe',form));if(id!==operation.current)return;const snapshot=answers.map((s,i)=>i===target?[s,data.text].filter(Boolean).join('\n').slice(0,5000):s);setAnswers(snapshot);retryAudio.current=null;await checkAnswer(snapshot,target,confirmed,id)}catch(e){if(id===operation.current){if(e instanceof Error&&e.message.startsWith('Не удалось расслышать'))retryAudio.current=null;showError(e)}}finally{if(id===operation.current)idle()}}
 async function startRecording(){if(busyRef.current)return;busyRef.current=true;setError('');setNotice('');setEditorOpen(false);retryAudio.current=null;canceled.current=false;setPhase('permission');setSeconds(0);const target=index;const recordingId=++operation.current;
  try{if(!navigator.mediaDevices?.getUserMedia||typeof MediaRecorder==='undefined')throw new Error('Запись недоступна в этом браузере. Используйте кнопку «Текст ответа» или откройте страницу в современном браузере по HTTPS.');const media=await navigator.mediaDevices.getUserMedia({audio:true});if(canceled.current||recordingId!==operation.current){media.getTracks().forEach(t=>t.stop());return}stream.current=media;const mime=['audio/webm;codecs=opus','audio/mp4','audio/ogg;codecs=opus'].find(t=>MediaRecorder.isTypeSupported(t));const rec=new MediaRecorder(media,mime?{mimeType:mime}:undefined);recorder.current=rec;chunks.current=[];rec.ondataavailable=e=>{if(e.data.size)chunks.current.push(e.data)};rec.onstop=()=>{media.getTracks().forEach(t=>t.stop());const blob=new Blob(chunks.current,{type:rec.mimeType});chunks.current=[];if(canceled.current||recordingId!==operation.current)return;void transcribe(blob,target)};rec.onerror=()=>{if(recordingId!==operation.current)return;canceled.current=true;media.getTracks().forEach(t=>t.stop());setError('Запись прервалась. Попробуйте ещё раз или откройте «Текст ответа».');idle()};rec.start(500);setPhase('recording')}
  catch(e){if(recordingId!==operation.current)return;stream.current?.getTracks().forEach(t=>t.stop());if(e instanceof DOMException&&e.name==='NotAllowedError')setError('Нет доступа к микрофону. Разрешите его в настройках сайта или откройте «Текст ответа».');else if(e instanceof DOMException&&e.name==='NotFoundError')setError('Микрофон не найден. Подключите его или откройте «Текст ответа».');else showError(e);idle()}
 }
 function stopRecording(){if(recorder.current?.state==='recording'){setPhase('transcribing');recorder.current.stop();stream.current?.getTracks().forEach(t=>t.stop())}}
 function cancelRecording(){canceled.current=true;operation.current++;if(recorder.current?.state==='recording')recorder.current.stop();stream.current?.getTracks().forEach(t=>t.stop());setNotice('Запись отменена. Предыдущий ответ сохранён.');idle()}
 async function generateResult(snapshot:string[],id:number){setView('finish');setPhase('generating');setStage('waiting');const data=VacancySchema.parse(await call('generate',JSON.stringify({answers:snapshot}),true));if(id!==operation.current)return;setResult(vacancyText(data));
  if(window.matchMedia('(prefers-reduced-motion: reduce)').matches){setView('result');return}
  setStage('shrink');await new Promise<void>(resolve=>{timers.current.push(setTimeout(resolve,500))});if(id!==operation.current)return;setStage('burst');await new Promise<void>(resolve=>{timers.current.push(setTimeout(resolve,950))});if(id!==operation.current)return;setView('result');setStage('waiting');
 }
 async function retryGenerate(){if(busyRef.current||count!==4)return;busyRef.current=true;setError('');const id=++operation.current;try{await generateResult(answers,id)}catch(e){if(id===operation.current)showError(e)}finally{if(id===operation.current)idle()}}
 function begin(){setMenuOpen(false);setError('');setNotice('');if(count===4){if(result)setView('result');else void retryGenerate()}else changeQuestion(confirmed.findIndex(v=>!v))}
 function reset(){setAnswers(empty());setConfirmed(unchecked());setAnalyses([null,null,null,null]);setAttempts([0,0,0,0]);setResult('');setView('intro');setIndex(0);setNotice('');setError('');setResetOpen(false);setEditorOpen(false);setStage('waiting');retryAudio.current=null}
 async function copy(){try{await navigator.clipboard.writeText(result);setNotice('Текст вакансии скопирован.')}catch{setNotice('Выделите текст и скопируйте вручную — браузер не разрешил автоматическое копирование.')}}
 function download(){const url=URL.createObjectURL(new Blob([result],{type:'text/plain;charset=utf-8'}));const link=document.createElement('a');link.href=url;link.download='Вакансия.txt';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
 const phaseText={idle:warning?'Нажмите, чтобы дополнить голосом':confirmed[index]?'Нажмите, чтобы дополнить ответ':'Нажмите, чтобы начать диктовку',permission:'Разрешите доступ к микрофону',recording:'Слушаю…',transcribing:'Распознаю речь…',analyzing:'Анализирую ответ…',generating:stage==='waiting'?'Собираю текст из ваших ответов…':'Вакансия сформирована'}[phase];
 const titleEnd=result.indexOf('\n\n');const roleTitle=titleEnd>=0?result.slice(0,titleEnd):result;const roleBody=titleEnd>=0?result.slice(titleEnd+2):'';
 const firstIncomplete=confirmed.findIndex(v=>!v);
 return <div className="app-shell">
  <aside className={'side-menu '+(menuOpen?'open':'')}><button className="brand" disabled={busy} onClick={()=>{setView('intro');setMenuOpen(false)}}><Asset name="sparkles"/><span>Искра</span><span className="brand-caption">помощник в подборе</span></button>
   <nav aria-label="Основные разделы"><button className="nav-item active" disabled={busy} onClick={()=>{setView('intro');setMenuOpen(false)}}><Asset name="sparkles"/>Помощник</button>{[['archive','Вакансии'],['team','Кандидаты'],['clock','Собеседования'],['document','Отчёты']].map(([icon,label])=><button className="nav-item" key={label} disabled title="Раздел показан для примера"><Asset name={icon}/>{label}</button>)}</nav>
   <div className="side-bottom"><span className="demo-caption">Демонстрационное пространство</span><button className="nav-item" onClick={()=>setHelpOpen(true)}><Asset name="help"/>Как это работает</button><button className="nav-item" disabled><Asset name="settings"/>Настройки</button><div className="profile"><span className="avatar">К</span><div><strong>Команда подбора</strong><span>Рабочее пространство</span></div><ChevronRight size={16}/></div></div>
  </aside>
  <main className="main-panel"><header className="topbar"><button className="mobile-menu icon-button" aria-label={menuOpen?'Закрыть меню':'Открыть меню'} aria-expanded={menuOpen} onClick={()=>setMenuOpen(!menuOpen)}>{menuOpen?<X/>:<Menu/>}</button><span className="page-name">{view==='intro'?'Помощник':'Создание вакансии'}</span><div className="header-actions"><span className="demo-pill"><span/>Демо</span><button className="icon-button" aria-label="Как это работает" onClick={()=>setHelpOpen(true)}><Asset name="help"/></button></div></header>
  {view==='intro'?<section className="dashboard enter"><Asset name="sparkles" className="home-spark"/><p className="eyebrow">МЕНЬШЕ РУТИНЫ. БОЛЬШЕ ЛЮДЕЙ.</p><h1 ref={heading} tabIndex={-1}>С чего начнём?</h1><p className="lead">Искра поможет с подбором.<br/>Выберите задачу — и займёмся ею вместе.</p><div className="quick-actions">{actions.map(([icon,title,description],i)=><button className={'quick-card '+(!i?'available':'')} key={title} onClick={i===0?begin:undefined} disabled={i>0}><div className="card-top"><Asset name={icon}/>{i>0?<span className="card-badge">Пример функции</span>:<ArrowRight size={21}/>}</div><h2>{!i&&answers.some(Boolean)?'Продолжить вакансию':title}</h2><p>{description}</p>{i===0&&answers.some(Boolean)&&<span className="saved-label">Сохранено {count} из 4 ответов</span>}</button>)}</div><p className="dashboard-note">В этой демоверсии можно создать вакансию. Остальные разделы показаны для примера.</p></section>:
  <div className="workspace">
   {view!=='result'&&<nav className="steps" aria-label="Вопросы для вакансии">{questions.map((q,i)=><button key={q.label} disabled={busy||(!confirmed[i]&&!answers[i]&&i!==firstIncomplete)} aria-current={view==='questions'&&i===index?'step':undefined} onClick={()=>changeQuestion(i)} className={'step '+(confirmed[i]?'done ':'')+(view==='questions'&&i===index?'selected':'')}><span className="step-number">{confirmed[i]?<Check size={14}/>:`0${i+1}`}</span><span>{q.label}</span></button>)}<span className="sr-only">Сохранено {count} из 4 ответов</span></nav>}
   {view==='result'?<section className="result-section enter"><div className="result-heading"><span className="success-mark"><Check size={16}/> Вакансия сформирована</span><h1 tabIndex={-1} ref={heading}>Ваши слова — готовый текст.</h1><p>Проверьте предложенное название и формулировки. Всё можно отредактировать.</p></div><div className="result-card"><label htmlFor="role-title">Название вакансии</label><input id="role-title" value={roleTitle} maxLength={150} onChange={e=>{setResult(e.target.value+'\n\n'+roleBody);setNotice('')}}/><label htmlFor="result">Описание вакансии</label><textarea id="result" value={roleBody} rows={15} maxLength={15500} onChange={e=>{setResult(roleTitle+'\n\n'+e.target.value);setNotice('')}}/></div><p className="notice" role="status">{notice}</p><div className="result-actions"><button className="primary" onClick={copy}><Copy size={17}/>Скопировать</button><button className="secondary" onClick={download}><Download size={17}/>Скачать .txt</button><button className="text-button" onClick={()=>changeQuestion(0)}><ArrowLeft size={16}/>К ответам</button><button className="text-button" onClick={()=>setResetOpen(true)}><RotateCcw size={15}/>Новая вакансия</button></div></section>:
   <section className="voice-flow"><Asset name="background" className="ambient"/><div className="flow-content"><Asset name="sparkles" className="flow-spark"/><p className="flow-intro">{view==='finish'?'Формирую вакансию…':'Для создания вакансии ответьте на вопросы'}</p><h1 tabIndex={-1} ref={heading}>{view==='finish'?(stage==='burst'?'Вакансия сформирована':'Почти готово…'):questions[index].title}</h1>
    <Ring confirmed={confirmed} index={index} warning={warning} phase={phase} stage={stage} finished={view==='finish'} onClick={()=>phase==='recording'?stopRecording():void startRecording()}/>
    <div className="voice-status" role="status"><p>{view==='finish'&&error?'Не удалось сформировать вакансию':phaseText}</p>{phase==='recording'&&<><SoundMeter source={stream.current}/><span className="record-time">{Math.floor(seconds/60)}:{String(seconds%60).padStart(2,'0')} / 2:00</span></>}</div>
    {error&&<div className="error-box" role="alert"><p>{error}</p>{retryAudio.current?<button className="text-button" disabled={busy} onClick={()=>{setError('');void transcribe(retryAudio.current!,index)}}><RotateCcw size={15}/>Повторить распознавание</button>:view==='finish'?<button className="text-button" disabled={busy} onClick={retryGenerate}><RotateCcw size={15}/>Попробовать снова</button>:answers[index]&&<button className="text-button" disabled={busy} onClick={retryAnalysis}>Повторить проверку</button>}</div>}
    {warning&&<div className="feedback" role="status"><p>{analysis.feedback}</p><p>{analysis.followUp}</p></div>}
    {notice&&<p className="notice" role="status">{notice}</p>}
    {view==='questions'&&<><div className="quiet-actions">{phase==='recording'||phase==='permission'?<button className="text-button" onClick={cancelRecording}>Отменить запись</button>:<button className="text-button" disabled={busy} aria-expanded={editorOpen} aria-controls="text-editor" onClick={()=>editorOpen?setEditorOpen(false):openEditor()}><FileText size={15}/>{editorOpen?'Скрыть текст':'Текст ответа'}</button>}{count===4&&!busy&&<button className="text-button" onClick={()=>result?setView('result'):void retryGenerate()}><ArrowRight size={15}/>{result?'К вакансии':'Сформировать вакансию'}</button>}</div>
    {editorOpen&&<div className="text-editor enter" id="text-editor"><div className="field-heading"><label htmlFor="answer">Ваш ответ</label><button className="icon-button" aria-label="Закрыть текст ответа" onClick={()=>setEditorOpen(false)}><X size={16}/></button></div><p>{questions[index].hint}</p><textarea id="answer" autoFocus value={draft} maxLength={5000} rows={5} onChange={e=>setDraft(e.target.value)} placeholder={questions[index].example}/><div className="editor-footer"><span>{draft.length} / 5000</span><button className="primary" disabled={busy||!draft.trim()} onClick={submitText}>Отправить<ArrowRight size={16}/></button></div></div>}
    <p className="privacy">До 2 минут на запись. После остановки аудио передаётся в Groq для распознавания.</p></>}
   </div></section>}
  </div>}
  </main>
  {(resetOpen||helpOpen)&&<div className="modal-shade" onKeyDown={e=>{if(e.key==='Tab'){const items=modalRef.current?.querySelectorAll<HTMLButtonElement>('button:not(:disabled)');if(items?.length){const first=items[0],last=items[items.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}}if(e.key==='Escape'){setResetOpen(false);setHelpOpen(false)}}}><div className="modal" ref={modalRef} role="dialog" aria-modal="true" aria-labelledby="modal-title"><button autoFocus className="icon-button modal-close" aria-label="Закрыть" onClick={()=>{setResetOpen(false);setHelpOpen(false)}}><X size={20}/></button><Asset name="sparkles"/><h2 id="modal-title">{resetOpen?'Начать новую вакансию?':'Расскажите о будущей работе'}</h2>{resetOpen?<><p>Ответы и текст будут удалены из этой вкладки. Сначала скопируйте или скачайте вакансию.</p><div className="modal-actions"><button className="secondary" onClick={()=>setResetOpen(false)}>Оставить</button><button className="primary" onClick={reset}>Начать заново</button></div></>:<><p>Ответьте на четыре вопроса. Нажмите на круг, чтобы начать диктовку, и ещё раз — чтобы закончить. Искра уточнит недостающие детали и соберёт текст.</p><p>«Текст ответа» позволяет писать и исправлять ответы. Верхние шаги возвращают к уже заполненному. Черновик сохраняется в этой вкладке.</p><p>Готовую вакансию можно отредактировать, скопировать и скачать. Автоматической публикации нет.</p><button className="primary" onClick={()=>setHelpOpen(false)}>Понятно</button></>}</div></div>}
 </div>
}
