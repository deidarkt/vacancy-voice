import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Вакансия голосом — от разговора к ясным требованиям",
  description: "Четыре ответа о работе, проектах и навыках — и редактируемый черновик вакансии.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      <body className="antialiased">{children}</body>
    </html>
  );
}
