// Small original cues, synthesized locally: no downloads, tracking or paid service.
export type Cue = 'start' | 'stop' | 'attention';
export class Earcons {
  private context: AudioContext | null = null;
  enabled = true;
  unlock() {
    if (!this.enabled) return;
    try {
      this.context ??= new AudioContext();
      void this.context.resume().catch(() => {});
    } catch { /* Audio is optional; the visual workflow remains available. */ }
  }
  play(cue: Cue): number {
    const ctx = this.context;
    if (!this.enabled || !ctx || ctx.state !== 'running') return 0;
    const notes = cue === 'start' ? [220, 330] : cue === 'stop' ? [330, 220] : [196, 196];
    try {
      notes.forEach((frequency, i) => {
        const oscillator = ctx.createOscillator(), gain = ctx.createGain();
        const t = ctx.currentTime + i * .12;
        oscillator.type = 'sine'; oscillator.frequency.value = frequency;
        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(.075, t + .015);
        gain.gain.exponentialRampToValueAtTime(.0001, t + .15);
        oscillator.connect(gain); gain.connect(ctx.destination);
        oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
        oscillator.start(t); oscillator.stop(t + .16);
      });
      return 290;
    } catch { return 0; }
  }
  close() { void this.context?.close().catch(() => {}); this.context = null; }
}
