import { z } from 'zod';

export const questions = [
  { label: 'Задачи', title: 'Какие две-три задачи сотрудник выполняет ежедневно?', hint: 'Назовите две-три конкретные задачи. Что человеку предстоит делать и с чем работать?', example: 'Например: проводить интервью с клиентами и проектировать интерфейсы личного кабинета.' },
  { label: 'Первые полгода', title: 'Над каким проектом сотрудник будет работать эти шесть месяцев?', hint: 'Расскажите о проекте или направлении работы и роли сотрудника. Если работа постоянная и без проекта, опишите её.', example: 'Например: улучшать личный кабинет клиентов или вести бухгалтерский учёт компании.' },
  { label: 'Планы', title: 'В следующие полгода он продолжит этот проект или возьмётся за другой? Какой именно?', hint: 'Работа продолжится в том же направлении или появится другое? Если планы ещё неизвестны, так и скажите.', example: 'Например: продолжит тот же проект. Или: пока не определили.' },
  { label: 'Навыки', title: 'Какими особыми инструментами, программами и знаниями он должен владеть, чтобы эффективно выполнять свою работу?', hint: 'Назовите важные навыки, знания и инструменты. Если особых требований нет, скажите об этом.', example: 'Например: Figma, проведение интервью и основы HTML. Или: специальным инструментам обучим.' },
] as const;

export const AnswersSchema = z.array(z.string().trim().max(5000)).length(4);
export const AnalysisInput = z.object({ questionIndex: z.number().int().min(0).max(3), answers: AnswersSchema, attempt: z.number().int().min(0).max(2).default(0) }).refine(v => v.answers[v.questionIndex].length > 0, 'Пустой ответ');
export const AnalysisSchema = z.object({ ready: z.boolean(), feedback: z.string().max(700), missing: z.array(z.string().max(300)).max(5), followUp: z.string().max(500) }).refine(v => v.ready || v.followUp.trim().length > 0, 'Нет уточнения');
export const VacancySchema = z.object({ title: z.string().min(1).max(150), dailyTasks: z.array(z.string().min(1).max(800)).min(1).max(12), currentProject: z.string().min(1).max(1500), nextProject: z.string().min(1).max(1500), requirements: z.array(z.string().min(1).max(800)).min(1).max(15) });
export const GenerateInput = z.object({ answers: AnswersSchema.refine(a => a.every(s => s.length > 0), 'Нужны четыре ответа') });
export type Analysis = z.infer<typeof AnalysisSchema>;
export type Vacancy = z.infer<typeof VacancySchema>;
export const emptyAnswers = () => ['', '', '', ''];
export function vacancyText(v: Vacancy) {
  return `${v.title}\n\nЕЖЕДНЕВНЫЕ ЗАДАЧИ\n${v.dailyTasks.map(s=>'• '+s).join('\n')}\n\nПЕРВЫЕ ШЕСТЬ МЕСЯЦЕВ\n${v.currentProject}\n\nЧТО ПЛАНИРУЕТСЯ ДАЛЬШЕ\n${v.nextProject}\n\nИНСТРУМЕНТЫ И ЗНАНИЯ\n${v.requirements.map(s=>'• '+s).join('\n')}`;
}
