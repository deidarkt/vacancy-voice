import { z } from 'zod';

export const questions = [
  { label: 'Задачи', title: 'Что сотрудник делает каждый день?', hint: 'Опишите две-три конкретные задачи. Что он делает и с чем работает?', example: 'Например: проводит интервью с клиентами и проектирует интерфейсы личного кабинета.' },
  { label: 'Проект', title: 'Над чем он работает эти полгода?', hint: 'Расскажите о текущем проекте и роли сотрудника. Для новой позиции — о первых шести месяцах.', example: 'Если работа не проектная, расскажите о постоянном направлении и результате работы.' },
  { label: 'Планы', title: 'А что будет в следующие полгода?', hint: 'Продолжит тот же проект или возьмётся за другой? Если за другой — какой?', example: 'Можно сказать «продолжит тот же проект» или «планы пока не определены».' },
  { label: 'Навыки', title: 'Что нужно знать и уметь?', hint: 'Какие инструменты, программы и знания нужны для этой работы?', example: 'Назовите действительно необходимые навыки. Если специальных требований нет, так и скажите.' },
] as const;

export const AnswersSchema = z.array(z.string().trim().max(5000)).length(4);
export const AnalysisInput = z.object({ questionIndex: z.number().int().min(0).max(3), answers: AnswersSchema }).refine(v => v.answers[v.questionIndex].length > 0, 'Пустой ответ');
export const AnalysisSchema = z.object({ ready: z.boolean(), feedback: z.string().max(700), missing: z.array(z.string().max(300)).max(5), followUp: z.string().max(500) }).refine(v => v.ready || v.followUp.trim().length > 0, 'Нет уточнения');
export const VacancySchema = z.object({ title: z.string().min(1).max(150), dailyTasks: z.array(z.string().min(1).max(800)).min(1).max(12), currentProject: z.string().min(1).max(1500), nextProject: z.string().min(1).max(1500), requirements: z.array(z.string().min(1).max(800)).min(1).max(15), missingDetails: z.array(z.string().min(1).max(300)).max(12) });
export const GenerateInput = z.object({ answers: AnswersSchema.refine(a => a.every(s => s.length > 0), 'Нужны четыре ответа') });
export type Analysis = z.infer<typeof AnalysisSchema>;
export type Vacancy = z.infer<typeof VacancySchema>;
export const emptyAnswers = () => ['', '', '', ''];
export function vacancyText(v: Vacancy) {
  return `${v.title}\n\nЕЖЕДНЕВНЫЕ ЗАДАЧИ\n${v.dailyTasks.map(s=>'• '+s).join('\n')}\n\nПРОЕКТ НА ПОЛГОДА\n${v.currentProject}\n\nСЛЕДУЮЩИЕ ПОЛГОДА\n${v.nextProject}\n\nИНСТРУМЕНТЫ И ЗНАНИЯ\n${v.requirements.map(s=>'• '+s).join('\n')}\n\nУТОЧНИТЬ ПЕРЕД ПУБЛИКАЦИЕЙ\n${v.missingDetails.map(s=>'• '+s).join('\n')}`;
}
